import { AppRouter } from './app/router';

export default function App() {
  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_bottom_left,rgba(15,23,42,0.06),transparent_24%),radial-gradient(circle_at_top_right,rgba(196,107,45,0.15),transparent_20%)]">
      <AppRouter />
    </div>
  );
}
